public interface Favorite {
    void addFavorite(Book book);
    void removeFavorite(Book book);
}
