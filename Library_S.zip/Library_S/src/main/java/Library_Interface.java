interface Library_Interface {
    void addBook(Book book);

    void removeBook(Book book);

}
