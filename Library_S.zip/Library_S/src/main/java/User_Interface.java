public interface User_Interface extends Borrowable, Favorite{
    String getName();
}
