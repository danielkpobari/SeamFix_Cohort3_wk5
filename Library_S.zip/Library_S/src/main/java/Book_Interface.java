public interface Book_Interface {
    String getTitle();
    String getAuthor();
}

